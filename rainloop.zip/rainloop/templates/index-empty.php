<div style="margin: 20px">
	<?php p($l->t('RainLoop Webmail is not configured yet.')); ?>
</div>