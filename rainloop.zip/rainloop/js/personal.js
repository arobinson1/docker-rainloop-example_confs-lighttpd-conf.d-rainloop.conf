
/**
 * ownCloud - RainLoop mail plugin
 *
 * @author RainLoop Team
 * @copyright 2017 RainLoop Team
 *
 * https://github.com/RainLoop/rainloop-webmail/tree/master/build/owncloud
 */

$(function() {
	RainLoopFormHelper('#mail-rainloop-personal-form', 'personal.php');
});
